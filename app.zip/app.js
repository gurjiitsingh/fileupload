const express = require('express')
const  multer = require('multer');
const bodyParser = require('body-parser')
//const path = require('path');
//const fileURLToPath = require('url');

const app = express();



app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static('../public'))

  const { multerImageRouter } = require("./routes/multerImageUpload.routes");
//import multerImageRouter  from './routes/multerImageUpload.routes.js'
app.use('/uploads', express.static('./uploads')) // file path
app.use('/upload', multerImageRouter)







module.exports = {
  app,
};