const { app } = require("./app");






app.listen(6000,(req, res)=>{
    console.log(`Server is running on port 6000`)
})